import 'dotenv/config';
import bcrypt from 'bcryptjs';
import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

async function main() {
  const passwordHash = await bcrypt.hash('password', 12);
  const admin = await prisma.user.upsert({ where: { email: 'admin@ground.local' }, update: { role: 'SUPER_ADMIN', status: 'ACTIVE' }, create: { firstName: 'Alex', lastName: 'Stone', email: 'admin@ground.local', passwordHash, role: 'SUPER_ADMIN', status: 'ACTIVE', emailVerified: true } });
  const objects = await prisma.category.upsert({ where: { slug: 'objects' }, update: {}, create: { name: 'Objects', slug: 'objects', description: 'Useful objects with a point of view.' } });
  const exists = await prisma.product.findUnique({ where: { sku: 'GROUND-001' } });
  if (!exists) await prisma.product.create({ data: { name: 'Ridge Ceramic Vase', slug: 'ridge-ceramic-vase', sku: 'GROUND-001', shortDescription: 'A quiet sculptural form for everyday spaces.', price: 64, status: 'ACTIVE', featured: true, categoryId: objects.id, images: { create: { url: 'https://images.unsplash.com/photo-1612196808214-b8e1d6145a8c?auto=format&fit=crop&w=700&q=80', altText: 'Ridge ceramic vase' } }, inventory: { create: { available: 12, movements: { create: { type: 'RESTOCK', quantity: 12, reason: 'Seed inventory' } } } } } });
  const zone = await prisma.shippingZone.upsert({ where: { id: 'seed-zone-global' }, update: {}, create: { id: 'seed-zone-global', name: 'Global standard', countries: ['GH', 'GHANA', 'US', 'GB'] } });
  await prisma.shippingMethod.upsert({ where: { id: 'seed-shipping-standard' }, update: {}, create: { id: 'seed-shipping-standard', zoneId: zone.id, name: 'Standard delivery', description: 'Reliable delivery for everyday orders.', rateType: 'FLAT', flatRate: 12, minDays: 3, maxDays: 5 } });
  await prisma.shippingMethod.upsert({ where: { id: 'seed-shipping-express' }, update: {}, create: { id: 'seed-shipping-express', zoneId: zone.id, name: 'Express delivery', description: 'Priority delivery when you need it sooner.', rateType: 'WEIGHT_BASED', flatRate: 20, perKgRate: 3, minDays: 1, maxDays: 2 } });
  console.log(`Seeded admin ${admin.email} and catalog data.`);
}

main().finally(() => prisma.$disconnect());
