#!/usr/bin/env bash
set -euo pipefail

if ! command -v docker >/dev/null 2>&1; then
  echo "Docker is required. Install Docker Engine and the Compose plugin first."
  exit 1
fi

if ! docker compose version >/dev/null 2>&1; then
  echo "Docker Compose v2 is required."
  exit 1
fi

if [ ! -f .env ]; then
  POSTGRES_PASSWORD="$(openssl rand -hex 24)"
  JWT_SECRET="$(openssl rand -hex 48)"
  cat > .env <<EOF
POSTGRES_PASSWORD=${POSTGRES_PASSWORD}
DATABASE_URL=postgresql://ground:${POSTGRES_PASSWORD}@postgres:5432/ground
JWT_SECRET=${JWT_SECRET}
PORT=4000
APP_PORT=4000
CORS_ORIGIN=http://localhost:4000
APP_URL=http://localhost:4000
SMTP_HOST=
SMTP_PORT=587
SMTP_SECURE=false
SMTP_USER=
SMTP_PASSWORD=
EMAIL_FROM=Ground <no-reply@example.com>
PAYSTACK_SECRET_KEY=
HUBTEL_WEBHOOK_SECRET=
MPESA_WEBHOOK_SECRET=
EOF
  echo "Created .env with generated database and JWT secrets. Update APP_URL and CORS_ORIGIN before public use."
fi

docker compose up -d --build
echo "Ground is running at http://localhost:${APP_PORT:-4000}"
echo "Health check: curl http://localhost:${APP_PORT:-4000}/health"
